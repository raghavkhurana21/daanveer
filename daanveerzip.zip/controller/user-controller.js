module.exports.about = (req,res)=>{

    return res.render('team.ejs');

}
module.exports.contact = (req,res)=>{

    return res.render('Contact.ejs');

}
module.exports.event = (req,res)=>{

    return res.render('event.ejs');

}
module.exports.contactUs = (req,res)=>{

    return res.render('contact1.ejs');

}
module.exports.volunteer=(req,res)=>{

    return res.render('volunteer.ejs');

}