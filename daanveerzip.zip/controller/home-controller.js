module.exports.home = (req,res)=>{

    return res.render('index.ejs',{
        title:"home"
    });

}